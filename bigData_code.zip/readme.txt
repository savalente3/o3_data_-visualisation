The execution of the code requires the installation of anaconda, there are mac and windows versins.
it includs the graphical installer and the terminal installer. However, i recomend the terminal 
installer, which can be download from:
https://www.anaconda.com/distribution/

After the installation of anaconda, the requirements.txt will install the remaining required packages
<conda install --file requirements.txt>

To run the code:
python3 bigData.py

To run the test:
python3 -m pytest tes_bigData.py